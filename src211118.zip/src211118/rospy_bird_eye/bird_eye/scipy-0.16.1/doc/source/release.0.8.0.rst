.. include:: ../release/0.8.0-notes.rst
