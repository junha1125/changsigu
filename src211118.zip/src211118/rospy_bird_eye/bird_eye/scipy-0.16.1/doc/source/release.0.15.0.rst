.. include:: ../release/0.15.0-notes.rst
