.. automodule:: scipy.sparse
