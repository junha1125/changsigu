.. automodule:: scipy.optimize

.. toctree::
   :hidden:
   :maxdepth: 1

   optimize.nonlin
