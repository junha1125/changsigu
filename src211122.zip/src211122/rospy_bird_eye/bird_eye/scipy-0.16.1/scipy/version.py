
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.16.1'
version = '0.16.1'
full_version = '0.16.1'
git_revision = 'a9fb36bc44bad4bbd2c1a41cb43c6f10925b38ae'
release = True

if not release:
    version = full_version
