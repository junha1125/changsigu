#!/usr/bin/env python
from __future__ import print_function

#import roslib
#roslib.load_manifest('my_package')
import sys
sys.path.append('/home/jetson/catkin_ws/src/rospy_bird_eye/bird_eye')
from vision import *
# from control import *
import rospy
import cv2
from std_msgs.msg import String
from std_msgs.msg import Float32
from std_msgs.msg import Int16
# from rospy_bird_eye.msg import Encoder
# from rospy_bird_eye.msg import TotalControl
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from datetime import datetime
import numpy as np
import math
import bisect
# from statistics import mean



###########################################################################################
#                                      Class Variables                                    #
###########################################################################################

class image_converter:
  def __init__(self):
    #### Vision team
    self.speedcmd_pub = rospy.Publisher("/speedcmd",Int16, queue_size=10)
    self.steercmd_pub = rospy.Publisher("/steercmd",Int16, queue_size=10)
    self.speedcmd = Int16
    self.steercmd = Int16

    self.speedcmd = 0
    self.steercmd = 90
    self.encoder = 0

    self.bridge = CvBridge()
    self.bev_image_past_frame = 0
    self.img0 = 0; self.img0_get_bool = False
    self.img1 = 0; self.img1_get_bool = False
    self.img2 = 0; self.img2_get_bool = False
    self.img3 = 0; self.img3_get_bool = False
    self.image_sub0 = rospy.Subscriber("/camera1/usb_cam1/image_raw",Image,self.callback0)
    self.image_sub1 = rospy.Subscriber("/camera2/usb_cam2/image_raw",Image,self.callback1)
    self.image_sub2 = rospy.Subscriber("/camera3/usb_cam3/image_raw",Image,self.callback2)
    self.image_sub3 = rospy.Subscriber("/camera4/usb_cam4/image_raw",Image,self.callback3)
    self.image_sub4 = rospy.Subscriber("/camera5/usb_cam5/image_raw",Image,self.callback4)
    self.image_sub5 = rospy.Subscriber("/camera6/usb_cam6/image_raw",Image,self.callback5)
    self.encoder_sub = rospy.Subscriber("/encoder",Float32, self.callback6)

    # Config
    class CONFIG():
      height, width = 448, 800
      front_shrink_pixel = 200
      right_shrink_pixel = 120
      car_front_length = width - 2 * front_shrink_pixel
      car_right_length = width - 2 * right_shrink_pixel
      height_bev = height * 2 + car_right_length
      width_bev = height * 2 + car_front_length
    self.opt = CONFIG


    ### Control team
    # Phase state
    self.Phase1 = 1
    self.Phase2 = 0
    self.Phase3 = 0
    self.Phase4 = 0
    self.Phase5 = 0
    self.Phase6 = 0

    # Autonomous parking direction
    self.direction = 1  # forward parking, direction = 2, backward parking

    # Back-GO Algorithm flague
    self.GoBack = 0

    ## Simulation setting
    self.ref_speed_F = 58
    self.ref_speed_B = -197
    # Phase 1
    self.ref_phase1_speed = self.ref_speed_F
    # Phase 2
    self.ref_phase2_speed = self.ref_speed_F
    # Phase 3
    self.ref_phase3_speed_F = self.ref_speed_F
    self.ref_phase3_speed_B = self.ref_speed_B
    # Phase 4
    self.ref_phase4_speed_F = self.ref_speed_B
    self.ref_phase4_speed_B = self.ref_speed_F
    # Phase 5
    self.ref_phase5_speed_F = self.ref_speed_F
    self.ref_phase5_speed_B = self.ref_speed_B
    # Phase 6
    self.ref_phase6_speed_F = self.ref_speed_F
    self.ref_phase6_speed_B = self.ref_speed_B

    ##  Control Parameter
    self.KX = 0.5
    self.KE = 90
    self.di_max = 40
    self.di_min = -40
    # Phase 1 : No control for distance, Only for yaw Control
    self.Phase1_KX = 0
    self.Phase1_KE = self.KE
    # Phase 2 : No Control
    # Phase 3 : Control for distance and yaw
    self.Phase3_KX = self.KX
    self.Phase3_KE = self.KE
    # Phase 4_Forward : Control for distance and yaw
    self.Phase4_F_KX = self.KX
    self.Phase4_F_KE = self.KE
    # Phase 4_Backward
    self.Phase4_B_KX = self.KX
    self.Phase4_B_KE = self.KE
    # Phase 5_Forward : No Control
    # Phase 5_Backward : No Control
    # Phase 6_Forward
    self.Phase6_F_KX = self.KX
    self.Phase6_F_KE = self.KE
    # Phase 6_Backward
    self.Phase6_B_KX = self.KX
    self.Phase4_B_KE = self.KE
    self.Obs = []
    self.Obs_y = []
    self.Camera_Obs = None

    # Vehicle Parameter
    self.L = 0.65
    self.hurry = 0.6
    self.momtong = 0.25

    ## Simulation Parameter
    # Phase 1
    self.Phase1_tolerance1 = 5 # Phase1 Point's Xdirection distance
    # Phase 2
    self.Phase2_tolerance1 = 5 # Phase2 Side Parking line's Yaw angle
    # Phase 3
    self.Phase3_tolerance1 = 5
    self.Phase3_tolerance2 = 5
    # Phase 4
    self.Phase4_tolerance1 = 5 # forward
    self.Phase4_tolerance2 = 5 # backward
    # Phase 5
    self.Phase5_tolerance1 = 5 # forward distance
    self.Phase5_tolerance2 = 5 # forward yaw tolerance
    self.Phase5_tolerance3 = 5 # backward distance
    self.Phase5_tolerance4 = 5 # backward yaw tolerance
    # Phase 6
    self.Phase6_tolerance1 = 0.05
    self.Phase6_tolerance2 = 350


  def callback0(self,data):
    try:
      self.img0 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")             # RGB 저장
      self.img0_get_bool = True
      # self.img0 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")[...,::-1] # BGR 저장
    except CvBridgeError as e:
      print(e)

  def callback1(self,data):
    try:
      self.img1 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
      self.img1_get_bool = True
      # self.img1 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")[...,::-1]
    except CvBridgeError as e:
      print(e)

  def callback2(self,data):
    try:
      self.img2 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
      self.img2_get_bool = True
      # self.img2 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")[...,::-1]
    except CvBridgeError as e:
      print(e)

  def callback3(self,data):
    try:
      self.img3 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
      self.img3_get_bool = True
      # self.img2 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")[...,::-1]
    except CvBridgeError as e:
      print(e)

  def callback4(self,data):
    try:
      self.img4 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
      self.img4_get_bool = True
      # self.img2 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")[...,::-1]
    except CvBridgeError as e:
      print(e)

  def callback5(self,data):
    try:
      self.img5 = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
      self.img5_get_bool = True

      if all([self.img0_get_bool,  self.img1_get_bool,  self.img2_get_bool,\
                self.img3_get_bool,  self.img4_get_bool,  self.img5_get_bool]) == True:
        # ==================== Start ====================
        _, _, _ = self.line_obstacle_detector()
        # self.bird_eye_view_drawer()

        ds = self.encoder 
        self.speedcmd,self.steercmd = self.AutonomousParking(ds, slopes_right_avg)


        # if slopes_left_avg is not None:
        #   slopes_left_avg = slopes_left_avg * (-1)
        # print(slopes_right_avg)
        # self.Camera_Obs = min_value
        # # Camera_Obs = obstacle detection
        # if slopes_right_avg is not None:
        #   slopes_right_avg = slopes_right_avg * math.pi / 180
        #   print('slopes_right_avg = ', slopes_right_avg * 180 / math.pi)
        # self.speedcmd,self.steercmd = self.PathTracking(ds, slopes_right_avg)
        # ==================== End ====================
        self.img0_get_bool, self.img1_get_bool, self.img2_get_bool, self.img3_get_bool, self.img4_get_bool,  self.img5_get_bool = False, False, False, False, False, False
        self.publish_drive()

    except CvBridgeError as e:
      print(e)

  def callback6(self,data):
    try:
      self.encoder = data.data
    except CvBridgeError as e:
     print(e)



  def publish_drive(self):
    try:
      self.speedcmd_pub.publish(self.speedcmd)
      self.steercmd_pub.publish(self.steercmd)
    except CvBridgeError as e:
      print(e)





###########################################################################################
#                                       Vision Team                                       #
###########################################################################################
  def bird_eye_view_drawer(self):
    # Perspective Transform Image
    img_pered_front = perspective_transform(self.img0, self.opt.front_shrink_pixel)
    img_pered_back = perspective_transform(self.img1, self.opt.front_shrink_pixel)
    img_pered_right = perspective_transform(self.img2, self.opt.right_shrink_pixel)
    img_pered_left = perspective_transform(self.img3, self.opt.right_shrink_pixel)

    # Bird Eye view full Image
    bev_image = np.zeros((self.opt.height_bev,self.opt.width_bev,3))
    center_rectangle_point = np.array([[self.opt.height, self.opt.height], [self.opt.width_bev-self.opt.height, self.opt.height],\
        [self.opt.width_bev-self.opt.height, self.opt.height+self.opt.car_right_length], [self.opt.height, self.opt.height+self.opt.car_right_length]], dtype=np.int32)
    cv2.fillConvexPoly(bev_image, center_rectangle_point, (255,255,255))     
    car_ellipse_pint = cv2.ellipse2Poly((int(self.opt.width_bev/2),int(self.opt.height_bev/2)), (int(self.opt.car_front_length*0.7), int(self.opt.car_right_length*0.53)),0,0,360,30)
    cv2.fillConvexPoly(bev_image, car_ellipse_pint, (0,0,0))     

    # Make Bird Eye view
    image_merging(self.opt, bev_image, img_pered_front, 'front')
    image_merging(self.opt, bev_image, np.rot90(img_pered_back, k=2), 'back')
    image_merging(self.opt, bev_image, np.rot90(img_pered_right, k=3), 'right')
    image_merging(self.opt, bev_image, np.rot90(img_pered_left, k=1), 'left')
    self.bev_image_past_frame = bev_image
    now = datetime.now()
    cv2.imwrite('bev_image_{}.jpg'.format(now.strftime("%M_%S")), bev_image[...,::-1])
    #bev_image = cv2.resize(bev_image, dsize=(int(self.opt.height_bev/6), int(self.opt.width_bev/6)), interpolation=cv2.INTER_NEAREST )
    #cv2.imshow('final', bev_image)
    #cv2.waitKey(1)
    rospy.loginfo(' --------  Saved bev_image  ---------===============================')
    return 


  def line_obstacle_detector(self):
    # Perspective Transform Image
    img_pered_front = perspective_transform(self.img0, self.opt.front_shrink_pixel)
    img_pered_back = perspective_transform(self.img1, self.opt.front_shrink_pixel)
    
    # Find lines
      # lines_front, slopes_front, length_front = lines_finder(img_pered_front, 'green', 'front')
      # lines_back, slopes_back, length_back = lines_finder(img_pered_back, 'green', 'back')
      # lines_right, slopes_right, length_right = lines_finder(np.rot90(self.img2, k=3), 'green', 'right')
      # lines_left, slopes_left, length_left = lines_finder(np.rot90(self.img3, k=1), 'green', 'left')

    # Select lines
    point, slope, length = slope_select(lines_finder(np.rot90(self.img3, k=1), 'green', 'left'), 90)

    # Find obstacles
      # _, dist_btw_front_obstacle = detect_obstacle_pt(img_pered_front, 'yellow')
      # _, dist_btw_back_obstacle = detect_obstacle_pt(img_pered_back, 'yellow')
  
    
    # cv2.imwrite('image_contour.jpg',contour_image)
    pass
      









###########################################################################################
#                                       Control Team                                      #
###########################################################################################
  def localization(self,ds):
    dx = ds * math.cos(self.yaw)
    dy = ds * math.sin(self.yaw)
    print('yaw',self.yaw)
    print('dy',dy)
    self.x = self.update(self.x, dx)# byun soo i reum : encoder, vision_yaw, obstacle_detect
    self.y = self.update(self.y, dy)

  def Constraint(self):
    if self.Obs_y > self.Phase6_tolerance2:
      v = 0
    else:
      if self.direction == 1:
        v = self.ref_phase6_speed_B
      elif self.direction == 2:
        v = self.ref_phase6_speed_F

    return v


  def update(self,x,dx):
      x = x + dx
      return x

  def feedback_control(self,yaw_error,x_error):
      omega = self.KX * x_error + self.KE * yaw_error
      return omega

  def AutonomousParking(self,ds,vision_yaw,vision_distance_L,vision_distance_R,vision_distance_F,vision_distance_B):
    # if No Yaw detection : Yaw = None
    # vision_x
    # vision_y

    if self.Phase1 == 1:
      ref_yaw = 0
      if vision_yaw is None:
        di = 0
      else:
        x_error = 0
        yaw_error = ref_yaw - vision_yaw
        self.KX = self.Phase1_KX
        self.KE = self.Phase1_KE
        di = self.feedback_control(yaw_error, x_error)
      if di >= self.di_max:
        di = self.di_max

      elif di <= self.di_min:
        di = self.di_min
      # Output
      di = di + 90

      output_velocity = self.ref_phase1_speed
      # Phase 1 end Constraint
      if vision_x > self.Phase1_tolerance1:
        self.Phase1 = 0
        self.Phase2 = 1
        output_velocity = 0
        di = 93
      output_steering = di


    elif self.Phase2 == 1:
      # Until vehicle's yaw is 180 degrees, Just steer Max(50degrees) degrees
      if vision_yaw < self.Phase2_tolerance1:
        self.Phase2 = 0
        self.Phase3 = 1
        output_velocity= 0
        di = 50

      else:
        output_velocity = self.ref_phase2_speed
        di = 50
      output_steering = di


    elif self.Phase3 == 1:
      ## Variable
      # vision_distance_L : Distance btw vehicle and left parking line
      # vision_distance_R : Distance btw vehicle and right parking line
      # vision_yaw : current yaw
      # parking_detection : Parking area detection
      # ref_point1 : ref_point1's x direction

      ref_yaw = 0 # or 180 degrees
      ref_y = 2
      current_y = vision_distance_L - vision_distance_R
      y_error = ref_y - current_y
      yaw_error = ref_yaw - vision_yaw
      self.KX = self.Phase3_KX
      self.KE = self.Phase3_KE
      di = self.feedback_control(yaw_error, y_error)
      di = di + 90

      if parking_detection == 0: # No detection
        output_velocity = self.ref_phase3_speed_F

        if vision_distance_L is None and vision_distance_R is None and output_velocity > 0:
          output_velocity = self.ref_phase3_speed_B

        elif vision_distance_L is None and vision_distance_R is None and output_velocity < 0:
          output_velocity = self.ref_phase3_speed_F

      elif parking_detection == 1: # Available Parking area detection
        if ref_point1 > self.Phase3_tolerance1:
          output_velocity = self.ref_phase3_speed_B
        elif ref_point1 < self.Phase3_tolerance2:
          output_velocity = self.ref_phase3_speed_F
        else:
          output_velocity = 0
          self.Phase3 = 0
          self.Phase4 = 1

      output_steering = di

    elif self.Phase4 == 1:
      ## Variable
      # vision_distance_L : Distance btw vehicle and left parking line
      # vision_distance_R : Distance btw vehicle and right parking line
      # vision_yaw : current yaw
      # parking_detection : Parking area detection
      # ref_point1 : ref_point1's x direction

      ref_yaw = 0 # or 180 degrees
      ref_y = 2
      current_y = vision_distance_L - vision_distance_R
      y_error = ref_y - current_y
      yaw_error = ref_yaw - vision_yaw
      self.KX = self.Phase3_KX
      self.KE = self.Phase3_KE
      di = self.feedback_control(yaw_error, y_error)
      di = di + 90

      if self.direction == 1: # forward Parking
        output_velocity = self.ref_phase4_speed_B
        if parking_detection == 0 and ref_point1 > self.Phase4_tolerance1:
          output_velocity = 0
          self.Phase4 = 0
          self.Phase5 = 1

      elif self.direction == 2: # backward Parking
        output_velocity = self.ref_phase3_speed_F
        if parking_detection == 1 and ref_point1 < self.Phase4_tolerance2:
          output_velocity = 0
          self.Phase4 = 0
          self.Phase5 = 1

      output_steering = di

    elif self.Phase5 == 1:
      ## Variable
      # vision_yaw : current yaw
      # ref_point2 : closest corner distance while cornering
      # GoBack : Goback Algorithm flague(arduino) when Goback algorithm ends, arduino should return self.GoBack = 0

      ref_yaw = 90
      yaw_error = ref_yaw - vision_yaw

      if self.direction == 1: # forward Parking
        output_velocity = self.ref_phase6_speed_F
        di = 130
        if yaw_error > self.Phase5_tolerance2 and ref_point2 < self.Phase5_tolerance1:
          output_velocity = 0
          self.GoBack = 1


      elif self.direction == 2:
        output_velocity = self.ref_phase6_speed_B
        di = 50
        if yaw_error > self.Phase5_tolerance2 and ref_point2 < self.Phase5_tolerance1:
          output_velocity = 0
          self.GoBack = 1

      output_steering = di


    elif self.Phase6 == 1:
      ## Variable
      # vision_yaw : current yaw
      # Camera_Obs : Camera Obstacle detection
      # Camera_y : distance btw vehicle & Obstacle (y-direction)
      # vision_distance_L : Distance btw vehicle and left parking line
      # vision_distance_R : Distance btw vehicle and right parking line
      self.KX = 0.5
      self.KE = 90

      # 앞쪽에 direction에 따라 어떤 카메라(전방,후방) 쓸껀지 정해주면 될듯.
      if vision_yaw is not None: # Parking line yaw detection
        yaw_error = vision_yaw

      else:
        yaw_error = 0

      if self.Camera_Obs is not None: # Obstacle detection using Camera
        print(' **************************** obstacle detection *************************')
        Camera_y = self.Camera_Obs
        self.Obs_y = Camera_y

      x_error = vision_distance_R - vision_distance_L
      di = self.feedback_control(yaw_error, x_error)

      if self.direction == 2:
        di = di * (-1)

      if di >= self.di_max:
          di = self.di_max

      elif di <= self.di_min:
          di = self.di_min

      di = di + 90
      output_velocity = self.Constraint()
      output_steering = di


    print('velocity & steering is : ', output_velocity,output_steering)
    return output_velocity, output_steering









###########################################################################################
#                                          MAIN                                           #
###########################################################################################
def main(args):
  rospy.init_node('listener', anonymous=True)
  ic = image_converter()

  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
  cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
